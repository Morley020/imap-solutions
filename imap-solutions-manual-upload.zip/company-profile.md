# iMap Digital Solutions Limited

## Company profile

**Digital systems for organizations building what is next.**

iMap Digital Solutions Limited is a Zambian technology and research company supporting organizations across health, education, agriculture, climate change, and development.

## Who we are

iMap is a joint venture between:

- VirTech Solutions, established in 2016 by telecommunications and IT engineers.
- Lutem Innovations, established in 2019.
- Adino Creations, founded in 2020.

Together, our team brings practical expertise across digital health, telecommunications, research, software, infrastructure, data, and creative problem solving.

## What we do

- IT equipment supply, including Dell and HP servers, desktop computers, laptops, and printers.
- Technical support and maintenance for operating systems, networking devices, servers, computers, databases, and accessories.
- Networking solutions, structured cabling, configuration, optimization, upgrades, and maintenance.
- Access control systems, CCTV installation and maintenance, and security design.
- Bulk SMS solutions for marketing, notifications, and system integrations.
- DHIS2 implementation, digital health consulting, REDCap, KoboToolbox, ERP systems, ETL tools, GIS, spatial mapping, and AI-powered solutions.
- Monitoring, evaluation, data collection, reporting, and full product development life-cycle support.

## Selected performance

Our work has supported organizations including the Office of the Auditor General, Zambia National Building Society, Zambia Sugar, KI, BBC Media Action, WWF, Aceh Executive Lodge, Charles Drew University, Zambia Open Community School, Acacia Engineering, and TMB Associates.

## Contact

Email: info@imapsolutions.co.zm  
Location: Lusaka, Zambia
